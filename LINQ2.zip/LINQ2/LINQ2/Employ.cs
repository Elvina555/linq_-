﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ2
{
    internal class Employ
    {
        public string Name { get; set; }
        public string department { get; set; }
    }
}
