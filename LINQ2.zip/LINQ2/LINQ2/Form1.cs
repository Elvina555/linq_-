﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LINQ2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<Department> department = new List<Department>()
            {
                new Department { Name = "Отдел закупок", Reg ="Германия" },
                new Department { Name = "Отдел продаж", Reg ="Испания" },
                new Department { Name = "Отдел маркетинга", Reg ="Испания" }
            };
            List<Employ> employes = new List<Employ>()
            {
                new Employ {Name="Иванов", department = "Отдел закупок"},
                new Employ {Name="Петров", department ="Отдел закупок"},
                new Employ {Name="Сидоров", department = "Отдел продаж "},
                new Employ {Name="Лямин", department = "Отдел продаж"},
                new Employ {Name="Сидоренко", department = "Отдел маркетинга"},
                new Employ {Name="Кривоносов", department = "Отдел продаж"}
            };
            //А
            var rez1 = from p in employes
            join p1 in department on p.department equals p1.Name 
            select new { Name_ = p.Name, Departments = p.department, Region = p1.Reg };
            foreach (var a in rez1)
            label3.Text += ($"{a.Name_}: {a.Departments}. Регион: {a.Region}\n");
            //Б
            var rez2 = from p2 in department
            join p3 in employes on p2.Name equals p3.department
            where p2.Reg.StartsWith("И")
            select p3.Name;
            foreach (var b in rez2)
            label4.Text += $"{b}\n";
        }
    }
}
