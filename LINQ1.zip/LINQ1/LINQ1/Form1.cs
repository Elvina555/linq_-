﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LINQ1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            List<People> people = new List<People>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден");
            }
            else
            {
                string[] a = File.ReadAllLines(file);
                People p1 = new People("", "", "", 0, 0);
                foreach (string b in a)
                {

                    string[] chelovek = b.Split(' ');
                    string name = chelovek[0];
                    p1.Set_Name(name);
                    string surname = chelovek[1];
                    p1.Set_Surname(surname);
                    string patronymic = chelovek[2];
                    p1.Set_Patronymic(patronymic);
                    int voz = Convert.ToInt32(chelovek[3]);
                    p1.Set_Voz(voz);
                    double ves = Convert.ToDouble(chelovek[4]);
                    p1.Set_Ves(ves);
                    label3.Text += ($"{p1.Get_Name()} {p1.Get_Surname()} {p1.Get_Patronymic()} {p1.Get_Voz()} {p1.Get_Ves()} \n");
                    people.Add(new People(name, surname, patronymic, voz, ves));
                    
                }
                var peo = from p in people
                where Convert.ToInt32(p.Get_Voz()) < 40
                select p;
                foreach (var a1 in peo)
                {
                    label4.Text += ($"Имя: {a1.Get_Name()} \nФамилия: {a1.Get_Surname()} \nОтчество: {a1.Get_Patronymic()}\nВозраст: {a1.Get_Voz()}\nВес: {a1.Get_Ves()}\n");
                }
            }
        }
    }
}
